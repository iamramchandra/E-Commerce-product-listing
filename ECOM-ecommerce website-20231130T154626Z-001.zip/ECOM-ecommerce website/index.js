let products = {
data: [
  {

    productName: "Regular White T-Shirt",
    category: "Clothing",
    price: "300",
    image: "images/new1.webp",
    inCart : 0
  },
  {
    
    productName: "Beige Short Skirt",
    category: "Clothing",
    price: "1900",
    image: "images/new2.webp",
    inCart : 0
  },

  {
    productName: "Basic Knitted Top",
    category: "Clothing",
    price: "2000",
    image: "images/new3.webp",
    inCart : 0
  },
  {
    productName: "Black Leather Jacket",
    category: "Clothing",
    price: "2999",
    image: "images/new4.webp",
    inCart : 0
  },

  {
    productName: "Stylish Pink Trousers",
    category: "Clothing",
    price: "1300",
    image: "images/pink-trousers.jpg",
    inCart : 0
  },

  {
    productName: "Brown Mens Jacket",
    category: "Clothing",
    price: "2000",
    image: "images/new5.webp",
    inCart : 0
  },

  {
    productName: "Comfy Gray Pants",
    category: "Clothing",
    price: "2300",
    image: "images/comfy-gray-pants.jpg",
    inCart : 0
  },
  {
    productName: "EIO New Born Baby Clothing Gift Set -13 Pieces",
    category: "Clothing",
    price: "499",
    image: "images/cloth1.jpg",
    inCart : 0
  },
  {
    productName: "BRANDONN Unisex Baby Panda Style Hooded Outwear",
    category: "Clothing",
    price: "664",
    image: "images/cloth2.jpg",
    inCart : 0
  },
  {
    productName: "APPLE iPhone 12 (White, 64 GB)",
    category: "Electronics",
    price: "48999",
    image: "images/elec3.jpeg",
    inCart : 0
  },
  {
    productName: "SONY WH-CH720N Bluetooth Headset",
    category: "Electronics",
    price: "9990",
    image: "images/elec1.jpeg",
    inCart : 0
  },
  {
    productName: "OnePlus Bullets Wireless Earphones ",
    category: "Electronics",
    price: "2299",
    image: "images/elec2.jpeg",
    inCart : 0
  },
  {
    productName: "Mi 5A 80 cm (32 inch) HD Ready LED Smart Android TV",
    category: "Electronics",
    price: "11499",
    image: "images/elec4.jpeg",
    inCart : 0
  },
  {
    productName: "ASUS Chromebook Flip Touch Celeron Dual Core ",
    category: "Electronics",
    price: "16990",
    image: "images/elec5.webp",
    inCart : 0
  },
  {
    productName: "Sporty SmartWatch",
    category: "Electronics",
    price: "4000",
    image: "images/sporty-smartwatch.jpg",
    inCart : 0
  },
  {
    productName: "Men Casual Brown Genuine Leather Wallet",
    category: "Accessories",
    price: "179",
    image: "images/asses1.webp",
    inCart : 0
  },
  {
    productName: "Grey, Black, White Women Sling Bag  (Pack of 3)",
    category: "Accessories",
    price: "229",
    image: "images/asses2.webp",
    inCart : 0
  },
  {
    productName: "Women Casual,Formal, Party Black Genuine Leather Belt",
    category: "Accessories",
    price: "299",
    image: "images/asses3.webp",
    inCart : 0
  },
],
};

for (let i of products.data) {
  //Create Card
  let card = document.createElement("div");
  //Card should have category and should stay hidden initially
  card.classList.add("card", i.category, "hide");
  //image div
  let imgContainer = document.createElement("div");
  imgContainer.classList.add("image-container");
  //img tag
  let image = document.createElement("img");
  image.setAttribute("src", i.image);
  imgContainer.appendChild(image);
  card.appendChild(imgContainer);
  //container
  let container = document.createElement("div");
  container.classList.add("container");
  //product name
  let name = document.createElement("h5");
  name.classList.add("product-name");
  name.innerText = i.productName.toUpperCase();
  container.appendChild(name);
  //price
  let price = document.createElement("h6");
  price.innerText = "₹" + i.price;
  container.appendChild(price);
  
  let btn = document.createElement("button");
  btn.classList.add("add-cart");
  btn.innerHTML = "Add to cart";
  container.appendChild(btn);
  card.appendChild(container);
  const elements = document.getElementById("products");
  if(elements)
  {
    document.getElementById("products").appendChild(card)
  } 
  
}


let carts = document.querySelectorAll('.add-cart');

for(let i=0; i<carts.length;i++){
  carts[i].addEventListener('click',() => {
    cartNumbers(products.data[i]);
    totalCost(products.data[i])
  })
}

function onLoadCartNumber(){
  let productNumbers = localStorage.getItem('cartNumbers');
   
  if(productNumbers){
    document.getElementById("count").innerHTML = productNumbers;
  }
}

function cartNumbers(product) {
  let productNumbers = localStorage.getItem('cartNumbers');
  productNumbers = parseInt(productNumbers);

  if(productNumbers){
    localStorage.setItem('cartNumbers', productNumbers +1);
    document.getElementById("count").innerHTML= productNumbers +1;

  } else {
    localStorage.setItem('cartNumbers',1);
    document.getElementById("count").innerHTML = 1;
  }
  setItems(product);
  
}
function setItems(product){
  let cartItems = localStorage.getItem('productsInCart');
  cartItems = JSON.parse(cartItems);
  if(cartItems != null) {
     
    if(cartItems[product.productName] == undefined){
      cartItems = {
        ...cartItems,
        [product.productName] : product 
      }
    }
    cartItems[product.productName].inCart += 1 ;
  } else{
    product.inCart = 1;
    cartItems = {
      [product.productName] : product
  }
}
localStorage.setItem("productsInCart", JSON.stringify(cartItems));
}

function totalCost(product){
  let cartCost = localStorage.getItem("totalCost");
  product.price = parseInt(product.price);
if(cartCost != null){
  cartCost = parseInt(cartCost);
  localStorage.setItem("totalCost", cartCost+
  product.price);
} else {
  
  localStorage.setItem("totalCost", product.price);
}
}

function deleteItemFromCart(productName) {
  let cartItems = localStorage.getItem("productsInCart");
  cartItems = JSON.parse(cartItems);

  if (cartItems && cartItems[productName]) {
    const deletedItemPrice = cartItems[productName].price * cartItems[productName].inCart;
    delete cartItems[productName];

    localStorage.setItem("productsInCart", JSON.stringify(cartItems));

    // Update the cart total cost
    let cartCost = localStorage.getItem("totalCost");
    cartCost = parseInt(cartCost) - deletedItemPrice;
    localStorage.setItem("totalCost", cartCost);

    // Refresh the cart display
    displayCart();
  let productNumbers = localStorage.getItem('cartNumbers');
  productNumbers = parseInt(productNumbers);

  if(productNumbers){
    localStorage.setItem('cartNumbers', productNumbers -1);
    document.getElementById("count").innerHTML= productNumbers -1;

  } else {
    localStorage.setItem('cartNumbers',0);
    document.getElementById("count").innerHTML = 0;
  }
  }
}


function displayCart(){
  let cartItems = localStorage.getItem("productsInCart");
  cartItems = JSON.parse(cartItems);
  
  let productContainer = document.querySelector(".productss");
  let cartCost = localStorage.getItem("totalCost");

  if(cartItems && productContainer ){
    productContainer.innerHTML = '';
    Object.values(cartItems).map(item => {
      productContainer.innerHTML += 
      `
    <div class="one-row">
      <div class = "product">
      <div class='row-img'>
      <img class='rowimg' src=${item.image}>
      </div>
      <p>${item.productName}</p>
      </div>
      <p class="price">₹${item.price}.00</p>
      <h3 class="quantityy">
      <span>${item.inCart}</span>

      </h3> 
      <p class="total">
      ₹${item.inCart * item.price}.00
      <i id="delete" class="fa-solid fa-trash" onclick="deleteItemFromCart('${item.productName}');"></i>
      </p>
    
      <div>
      `;  
    });
    productContainer.innerHTML += 
    `
    <div class="basketTotalContainer">
      <h4 class="basketTotalTitle">
        Basket Total
      </h4>
      <h4 class="basketTotal">
        ₹${cartCost}.00
      </h4>
    </div>`
  
}
}
onLoadCartNumber();
displayCart();

  //parameter passed from button (Parameter same as category)
  function filterProduct(value) {
    //Button class code
    let buttons = document.querySelectorAll(".button-value");
    buttons.forEach((button) => {
      //check if value equals innerText
      if (value.toUpperCase() == button.innerText.toUpperCase()) {
        button.classList.add("active");
      } else {
        button.classList.remove("active");
      }
    });
  
    //select all cards
    let elements = document.querySelectorAll(".card");
    //loop through all cards
    elements.forEach((element) => {
      //display all cards on 'all' button click
      if (value == "all") {
        element.classList.remove("hide");
      } else {
        //Check if element contains category class
        if (element.classList.contains(value)) {
          //display element based on category
          element.classList.remove("hide");
        } else {
          //hide other elements
          element.classList.add("hide");
        }
      }
    });
  }
  
  const search = document.getElementById("search");
  if(search){
  //Search button click
  document.getElementById("search").addEventListener("click", () => {
    //initializations
    let searchInput = document.getElementById("search-input").value;
    let elements = document.querySelectorAll(".product-name");
    let cards = document.querySelectorAll(".card");
  
    //loop through all elements
    elements.forEach((element, index) => {
      //check if text includes the search value
      if (element.innerText.includes(searchInput.toUpperCase())) {
        //display matching card
        cards[index].classList.remove("hide");
      } else {
        //hide others
        cards[index].classList.add("hide");
      }
    });
  });
}
  //Initially display all products
  window.onload = () => {
    filterProduct("all");
  };